#!/usr/bin/env python3
"""Restaure les fichiers éditables de MEDINA_Alpha, sans toucher MEDINA_0."""
import gzip,json,sys
from pathlib import Path
if len(sys.argv)!=3:
    raise SystemExit('Usage : python3 RESTAURER_MEDINA_Alpha.py MEDINA_Alpha_SOURCES.json.gz DOSSIER_VIDE')
archive=Path(sys.argv[1]);destination=Path(sys.argv[2]).resolve()
if destination.exists() and any(destination.iterdir()):
    raise SystemExit('Le répertoire de destination doit être vide pour éviter tout écrasement.')
with gzip.open(archive,'rt',encoding='utf-8') as f: files=json.load(f)
if not isinstance(files,dict):raise SystemExit('Archive source invalide.')
for relative,content in files.items():
    if not isinstance(content,str) or Path(relative).is_absolute():raise SystemExit('Chemin ou contenu invalide.')
    target=(destination/relative).resolve()
    if not target.is_relative_to(destination) or target==destination:raise SystemExit('Chemin refusé : '+relative)
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(content,encoding='utf-8')
print(f'{len(files)} fichiers restaurés dans {destination}')
print('Pour reconstruire le HTML : cd',destination,'puis python3 build_front.py')
